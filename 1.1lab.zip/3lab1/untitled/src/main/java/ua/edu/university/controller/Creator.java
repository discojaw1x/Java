package ua.edu.university.controller;

public interface Creator {
    Object create(Object ... objects);
}
