package ua.edu.university.model;

public enum Sex {
    MALE,
    FEMALE
}
