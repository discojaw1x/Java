package ua.edu.university.model;

import ua.edu.university.model.*;

public class Student extends Human {

    public Student(String firstName, String middleName, String lastName, Sex sex) {
        super(firstName, middleName, lastName, sex);
    }


}
